package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Window;
import java.io.File;

public class Controller {

    public void openFileButton() {
    // Logic for opening a file from user PC to be added here
    }

    public void compileButton() {
    // Logic for running the compiler to be added here
    }

    public void clipboardButton() {
    // Logic for clipboard functionality to be added here
    }

    public void saveToFileButton() {
    // Logic to save output as a text file to be added here
    }

    public void menuBarFile() {

    }

    public void menuBarEdit() {

    }

    public void menuBarHelp() {

    }
}

