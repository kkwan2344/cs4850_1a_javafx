package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.Window;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;

public class Controller extends Main {

    //you can ignore this code as I was trying out how to link controller functions to testfxml2.fxml
    //feel free to create all the objects with whatever names you find the most convenient and I will update the fxml tags and id's to match what you have
    /*
    @FXML public Button buttonTest;
    @FXML public Button buttonTwo;
    public void handleButtonClick() {
        System.out.println("This is a test.");
        buttonTest.setText("Confirmed!");
    }
    */


     public void fileSaveAction(Stage primaryStage, TextArea outputText) {
        FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Python File (*.py)", "*.py");
        fileChooser.getExtensionFilters().add(extFilter);

        File file = fileChooser.showSaveDialog(primaryStage);

        try {
            FileWriter fileWriter = null;

            fileWriter = new FileWriter(file);
            fileWriter.write(outputText.getText());
            fileWriter.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void compileButton() {
    // Logic for running the compiler to be added here
    }

    public void clipboardButton() {
    // Logic for clipboard functionality to be added here
    }

    //the method to run off the open file button.
    public void fileToString(Stage primaryStage, TextArea inputText) {
        //create file chooser using the passed stage and textArea
        FileChooser fileChooser = new FileChooser();
        File sourceFile = fileChooser.showOpenDialog(primaryStage);
        FileInputStream fis = null;
        String str = "";
        //import java or txt file into string
        try {
            fis = new FileInputStream(sourceFile);
            int content;
            while ((content = fis.read()) != -1) {
                // convert to char and display it
                str += (char) content;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fis != null)
                    fis.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        //set the created string in the input field
        inputText.setText(str);
    }

    public void convertToPython(TextArea inputText, TextArea outputText) {
        //import the text in the input area
        String input = inputText.getText();

        //call the compiler code here

        //set output text field to be the product (hopefully a string, otherwise can just call the filetostring method)
        outputText.setText("Placeholder text until compiler is finished. Displaying copy of input code for now.\n" + input);

    }

    }



